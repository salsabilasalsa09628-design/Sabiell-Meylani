# Portfolio Anonim

Website portofolio sederhana dan elegan yang siap diunggah ke GitHub Pages.

## Cara Upload ke GitHub
1. Buat repository baru di GitHub.
2. Upload semua file di folder ini.
3. Masuk ke Settings → Pages.
4. Pilih branch `main` dan folder `/root`.
5. Website akan online melalui GitHub Pages.
